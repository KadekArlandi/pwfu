<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Latihan 03</title>
</head>
<body>
    <h1>Hallo</h1>
    nama saya <strong><?php echo e($nama); ?></strong>, hobi saya antara lain:
    <ul>
        <?php $__currentLoopData = $hobi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($val); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <p>Berikut Skill yang saya miliki:</p>
    <ul>
        <?php for($a = 0; $a < count($skill); $a++): ?>
            <li><?php echo e($skill[$a]); ?></li>
        <?php endfor; ?>
    </ul>

</body>
</html><?php /**PATH C:\xampp\htdocs\akomodasi-app\resources\views/m4/lat3.blade.php ENDPATH**/ ?>