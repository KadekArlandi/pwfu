<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="container p-5 bg-success text-white text-center">
        <h1>IDENTITAS</h1>
        <p>Berikut ini merupakan identitas saya</p>
    </div>

    <div class="container mt-3">
        <table class="table table-bordered">
            <tr>
                <th>Nama</th>
                <td>KADEK ARLANDI MAHESA GAUTAMA PUTRA</td>
            </tr>
            <tr>
                <th>Alamat</th>
                <td>Perum. Taman Sri Wedari Gg.7, No.3, Cepaka, Selingsing, Kediri, Tabanan</td>
            </tr>
            <tr>
                <th>Jenis Kelamin</th>
                <td>Laki-laki</td>
            </tr>
            <tr>
                <th>Nomor Telepon</th>
                <td>08765432123</td>
            </tr>
            <tr>
                <th>Email</th>
                <td>example@gmail.com</td>
            </tr>
        </table>
    </div>

    <div class="container mt-3">
    <a href="<?php echo route('pendidikan') ?>"><button class="btn btn-primary" type="button">Pendidikan</button></a>
    <a href="<?php echo route('skill') ?>"><button class="btn btn-primary" type="button">Skill</button></a>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\akomodasi-app\resources\views/cv/identitas.blade.php ENDPATH**/ ?>