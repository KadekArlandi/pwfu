<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Identitas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

    <div class="container p-5 bg-success text-white text-center">
        <h1>IDENTITAS</h1>
        <p>Dibawah ini adalah identitas saya</p>
    </div>

    <div class="container mt-3">
        <h2>Selamat Datang di halaman Identitas saya!</h2>
        <p>Saya sedang belajar Pemrograman Web Framework</p>
        <table class="table table-bordered">
            <tr>
                <th>Nama Lengkap</th>
                <td>Komang Agus Anjas Putra</td>
            </tr>
            <tr>
                <th>Nama Panggilan</th>
                <td> Anjas </td>
            </tr>
            <tr>
                <th>Alamat</th>
                <td>Jl. Cermai Lingk Roban, Bitera, Gianyar</td>
            </tr>
            <tr>
                <th>Jenis Kelamin</th>
                <td>Laki-laki</td>
            </tr>
            <tr>
                <th>Nomor Telepon</th>
                <td>08970415186</td>
            </tr>
            <tr>
                <th>Email</th>
                <td>agusanjas11@gmail.com</td>
            </tr>
        </table>
    </div>

    <div class="container mt-3">
    <a href="<?php echo route('pendidikan') ?>"><button class="btn btn-primary" type="button">Pendidikan</button></a>
    <a href="<?php echo route('skill') ?>"><button class="btn btn-primary" type="button">Skill</button></a>
    </div>

</body>

</html><?php /**PATH C:\xampp\htdocs\akomodasi-app\resources\views/identitas.blade.php ENDPATH**/ ?>