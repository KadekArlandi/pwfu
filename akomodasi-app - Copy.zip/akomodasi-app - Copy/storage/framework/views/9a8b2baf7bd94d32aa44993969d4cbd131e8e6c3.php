<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendidikan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    
<div class="container p-5 bg-primary text-white text-center">
        <h1>PENDIDIKAN</h1>
        <p>Dibawah ini adalah pendidikan saya</p>
    </div>

    <div class="container mt-3">
        <h2>Selamat Datang di halaman Pendidikan saya!</h2>
        <p>Saya sedang belajar Pemrograman Web Framework</p>
        <table class="table">
            <tr class="table-warning">
                <td>Sekolah Dasar Negeri 1 Buduk</td>
                <td>Tahun 2010-2016</td>
            </tr>
            <tr class="table-primary">
                <td>Sekolah Menengah Pertama Negeri 3 Mengwi</td>
                <td>Tahun 2016-2019</td>
            </tr>
            <tr class="table-secondary">
                <td>Sekolah Menengah Atas Negeri 2 Mengwi</td>
                <td>Tahun 2019-2022</td>
            </tr>
            <tr class="table-danger">
                <td>Institut Bisnis dan Teknologi Indonesia (INSTIKI)</td>
                <td>Tahun 2022-Sekarang</td>
            </tr>
        </table>
    </div>

    <div class="container mt-3">
    <a href="<?php echo route('identitas')?>"><button class="btn btn-primary" type="button">Identitas</button></a>
    <a href="<?php echo route('skill')?>"><button class="btn btn-primary" type="button">Skill</button></a>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\akomodasi-app\resources\views/cv/pendidikan.blade.php ENDPATH**/ ?>