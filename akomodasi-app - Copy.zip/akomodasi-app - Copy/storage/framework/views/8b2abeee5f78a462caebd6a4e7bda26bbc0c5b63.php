<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skill</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

    <div class="container p-5 bg-danger text-white text-center">
        <h1>SKILL</h1>
        <p>Dibawah ini adalah skill saya</p>
    </div>

    <div class="container mt-3">
        <h2>Selamat Datang di halaman Skill saya!</h2>
        <p>Saya sedang belajar Pemrograman Web Framework</p>

        <b>HTML</b>
        <div class="progress">
            <div class="progress-bar bg-success" style="width:90%"></div>
        </div>
        <b>CSS</b>
        <div class="progress">
            <div class="progress-bar" style="width:80%"></div>
        </div>
        <b>JAVASCRIPT</b>
        <div class="progress">
            <div class="progress-bar bg-warning" style="width:60%"></div>
        </div>
        <b>PHP</b>
        <div class="progress">
            <div class="progress-bar bg-secondary" style="width:75%"></div>
        </div>
        <b>FRAMEWORK</b>
        <div class="progress">
            <div class="progress-bar bg-info" style="width:70%"></div>
        </div>
        <b>PYTHON</b>
        <div class="progress">
            <div class="progress-bar bg-info" style="width:70%"></div>
        </div>
    </div>

    <div class="container mt-3">
        <a href="<?php echo route('identitas') ?>"><button class="btn btn-primary" type="button">Identitas</button></a>
        <a href="<?php echo route('pendidikan') ?>"><button class="btn btn-primary" type="button">Pendidikan</button></a>
    </div>

</body>

</html><?php /**PATH C:\xampp\htdocs\akomodasi-app\resources\views/skill.blade.php ENDPATH**/ ?>