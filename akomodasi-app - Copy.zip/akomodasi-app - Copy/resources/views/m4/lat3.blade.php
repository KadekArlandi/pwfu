<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Latihan 03</title>
</head>
<body>
    <h1>Hallo</h1>
    nama saya <strong>{{ $nama }}</strong>, hobi saya antara lain:
    <ul>
        @foreach ($hobi as $val)
            <li>{{ $val }}</li>
        @endforeach
    </ul>
    <p>Berikut Skill yang saya miliki:</p>
    <ul>
        @for ($a = 0; $a < count($skill); $a++)
            <li>{{ $skill[$a] }}</li>
        @endfor
    </ul>

</body>
</html>