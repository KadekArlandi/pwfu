<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class M4Controller extends Controller
{
    public function lat1(){
        $nama = 'Komang Agus Anjas Putra';
        $alamat = 'Gianyar';
        return view('m4.lat1', compact('nama', 'alamat'));
    }

    public function lat2(){
        $nama = 'komang Agus Anjas Putra';
        $nilai = 65;
        return view('m4.lat2', compact('nama', 'nilai'));
    }

    public function lat3(){
        $nama = 'komang Agus Anjas Putra';
        $hobi = ['Makan', 'travel', 'tidur'];
        $skill = ['HTML', 'CSS', 'PHP'];
        return view('m4.lat3', compact('nama', 'hobi', 'skill'));
    }
    
    public function m4_identitas(){
        $nama = 'komang Agus Anjas Putra';
        $alamat = 'Gianyar';
        return view('m4.identitas', compact('nama', 'alamat'));
    }
}
