<?php

use App\Http\Controllers\M4Controller;
use App\http\Controllers\CVController;
use App\Http\controllers\PageController;
use Illuminate\Support\Facades\Route;

Route::get('m4/lat1', [M4Controller::class, 'lat1']);
Route::get('m4/lat2', [M4Controller::class, 'lat2']);
Route::get('m4/lat3', [M4Controller::class, 'lat3']);

Route::get('m4/identitas', [M4Controller::class, 'm4_identitas'])->name('m4.identitas');

Route::get('/identitas', [CVController::class, 'identitas'])->name('identitas');
Route::get('/pendidikan', [CVController::class, 'pendidikan'])->name('pendidikan');
Route::get('/skill', [CVController::class, 'skill'])->name('skill');


Route::view('/home', 'home');

Route::get('awal', function(){
$url = route('kontak');
echo '<a href="' . $url . '">Klik disini untuk kontak saya</a>';
});

Route::get('/kontak', function(){
    echo 'ini adalah halaman kontak saya';
})->name('kontak');

Route::get('/detail/{nama}/{alamat}', function($nama, $alamat = ''){
    echo 'Hallo, perkenalkan nama saya ' . $nama . ', alamat saya di ' . $alamat;
});

Route::get('/tampil/{nama}', function($nama){
    echo 'Hallo, perkenalkan nama saya ' . $nama;
});

Route::get('/greeting', function(){
    echo 'Hello, saya mencoba route bang';
});

Route::get('/', function () {
    return view('welcome');
});
